Link to public github repo "https://github.com/habiburrehman012/onlineShoppingportal"

INTRODUCTION:
Task was about online shopping portal on which by default some values are displayed and you add items in your cart. You
can filter contents on basis of price, specifications or name.

What I've Done My Approach:
My approach to task was by using controller that has an object whose memmbers are arrays those are item types for example
laptop, food, cloth and mobile and the searching is not completely done but it searches on basis of characters entered. To enter to cart was to introduce a function that would dynamically generated table for items that user clicked that unfortunately is not done.

How to Run?
Extract it and run .html file in browser and enter in search box to search contents.